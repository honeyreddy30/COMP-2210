import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;

import java.util.Arrays;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Scanner;
import java.util.TreeSet;

import java.util.stream.Collectors;

/**
 * Provides an implementation of the WordLadderGame interface. 
 *
 * @author Your Name (hzn0030@auburn.edu)
 */
public class Doublets implements WordLadderGame {
    List<String> LADDER_IS_EMPTY = new ArrayList<>();
    TreeSet<String> lexicon;

    // The word list used to validate words.
    // Must be instantiated and populated in the constructor.
    /////////////////////////////////////////////////////////////////////////////
    // DECLARE A FIELD NAMED lexicon HERE. THIS FIELD IS USED TO STORE ALL THE //
    // WORDS IN THE WORD LIST. YOU CAN CREATE YOUR OWN COLLECTION FOR THIS     //
    // PURPOSE OF YOU CAN USE ONE OF THE JCF COLLECTIONS. SUGGESTED CHOICES    //
    // ARE TreeSet (a red-black tree) OR HashSet (a closed addressed hash      //
    // table with chaining).
    /////////////////////////////////////////////////////////////////////////////

    /**
     * Instantiates a new instance of Doublets with the lexicon populated with
     * the strings in the provided InputStream. The InputStream can be formatted
     * in different ways as long as the first string on each line is a word to be
     * stored in the lexicon.
     */
    public Doublets(InputStream in) {
        try {
            lexicon = new TreeSet<String>();
            Scanner s =
                new Scanner(new BufferedReader(new InputStreamReader(in)));
            while (s.hasNext()) {
                String str = s.next();
                lexicon.add(str.toLowerCase());
                s.nextLine();
            }
            in.close();
        }
        catch (java.io.IOException e) {
            System.err.println();
            System.exit(1);
        }
    }
    public int getHammingDistance(String strA, String strB) 
    {
      int outcome = 0;
      if (strA.length() != strB.length()) 
      {
         return -1; 
      }
   
      for (int i = 0; i < strA.length(); i++) 
      {
         if (strA.charAt(i) != strB.charAt(i)) 
         {
            outcome++;
         }
      }
      return outcome;
   }
    public List<String> getLadder(String begin, String end) 
{
      List<String> outcome = new ArrayList<String>();
        
      if (begin.equals(end)) 
      {
         outcome.add(begin);
         return outcome;
      }
      else if (begin.length() != end.length()) 
      {
         return LADDER_IS_EMPTY;
      }
      else if (!isWord(begin) || !isWord(end)) 
      {
         return LADDER_IS_EMPTY;
      }
          
      TreeSet<String> first = new TreeSet<>();
      Deque<String> stack = new ArrayDeque<>();
       
      stack.addLast(begin);
      first.add(begin);
      while (!stack.isEmpty()) 
      {
       
         String currentA = stack.peekLast();
         if (currentA.equals(end)) 
         {
            break;
         }
         List<String> neighborsA = getNeighbors(currentA);
         List<String> neighborsB = new ArrayList<>();
          
         for (String word : neighborsA) 
         {
            if (!first.contains(word)) 
            {
               neighborsB.add(word);
            }
         }
         if (!neighborsB.isEmpty()) 
         {
            stack.addLast(neighborsB.get(0));
            first.add(neighborsB.get(0));
         }
         else 
         {
            stack.removeLast();
         }
      }
      outcome.addAll(stack);
      return outcome;
   }
    public List<String> getMinLadder(String begin, String end) {
      List<String> ladder = new ArrayList<String>();
      if (begin.equals(end)) {
         ladder.add(begin);
         return ladder;
      }
      else if (begin.length() != end.length()) {
         return LADDER_IS_EMPTY;
      }
      else if (!isWord(begin) || !isWord(end)) {
         return LADDER_IS_EMPTY;
      }
    
      Deque<Node> h = new ArrayDeque<>();
      TreeSet<String> first = new TreeSet<>();
    
      first.add(begin);
      h.addLast(new Node(begin, null));
      while (!h.isEmpty()) {
       
         Node r = h.removeFirst();
         String place = r.place;
          
         for (String neighborA : getNeighbors(place)) {
            if (!first.contains(neighborA)) {
               first.add(neighborA);
               h.addLast(new Node(neighborA, r));
            }
            if (neighborA.equals(end)) {
             
               Node n = h.removeLast();
               
               while (n != null) {
                  ladder.add(0, n.place);
                  n = n.predec;
               }
               return ladder;
            }
         }
      }      
      return LADDER_IS_EMPTY;
   }
     public List<String> getNeighbors(String word) {
      List<String> neighbor = new ArrayList<String>();
      TreeSet<String> sets= new TreeSet<String>();
       
      if (word == null)
         return LADDER_IS_EMPTY;
      
      for (String h : lexicon) 
      {
         if (getHammingDistance(word, h) == 1)
            neighbor.add(h);
      }
      
      return neighbor;
   }
    public int getWordCount() 
    {
      int count = lexicon.size();
      return count;
   }
    public boolean isWord(String str)
 {
      if (lexicon.contains(str))
      {
         return true;
      }
      return false;
   }
    public boolean isWordLadder(List<String> seq) {
      int count = 0;
      if ((seq == null) || (seq.isEmpty())) {
         return false;
      }
      
      for (int i = 0; i < seq.size() - 1; i++){
         if (isWord(seq.get(i)) != true || isWord(seq.get(i + 1)) != true || (getHammingDistance(seq.get(i), seq.get(i + 1)) != 1))
            count++;  
      }
      boolean x = (count == 0);
      return x;
   }
   
   private class Node {
      String place;
      Node predec;
   
      public Node(String h, Node pred) {
         place = h;
         predec = pred;
      }
   }
}

